<?php 
session_start();

 if(!isset($_SESSION['nomeUsuario']) || isset($_SESSION['sair'])){
    session_destroy();
    header("Location: login/login.php");
 } 

?>

<table class="table">
	<thead>
		<th>Nome</th>
		<th>Cargo</th>
		<th>Empresa</th>
                <th>Tipo Empresa</th>
		<th>Email</th>
		<th>Assunto</th>
		<th>Editar</th>
                <th>Remover</th>
	</thead>
	<tbody>
                <?php if (empty($contatosCadastrados)):?>
                    <tr>
                        <td colspan="8">Nenhum contato cadastrado.</td>
                    </tr>
            
                <?php endif;?>
            
		<?php foreach ($contatosCadastrados as $objDadosContato):?>
			<tr>
				<td><?= $objDadosContato->nome ?></td>
				<td><?= $objDadosContato->cargo ?></td>
				<td><?= $objDadosContato->empresa ?></td>
				<td><?= $objDadosContato->tipo?></td>
				<td><?= $objDadosContato->email ?></td>
                                <td><?= $objDadosContato->assunto ?></td>
				<td>
                                    <span class="glyphicon glyphicon-pencil btn btn-default btn-xs" onclick="obtemFormContatos('N', <?= $objDadosContato->id ?>)"></span>
				</td>
                                <td>
                                    <span class="glyphicon glyphicon-remove btn btn-default btn-xs btn-danger" onclick="removeContato(<?= $objDadosContato->id ?>)"></span>
                                </td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<button type="button" onclick="obtemFormContatos('S','')" class="btn btn-success">Cadastrar novo contato</button>
<div id="modalForm"></div>


