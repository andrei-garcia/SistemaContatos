<nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
            <span class="sr-only">Filtro</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Filtro rápido</a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
          <form id="filtroContatos" class="navbar-form navbar-left" role="search">
            <div class="form-group">
                <input type="text" class="form-control" id="n1" name="filtro_nome" value="" placeholder="Nome">
            </div>
              <div class="form-group">
                  <select class="form-control" class="form-control" id="n5" name="filtro_empresa_id">
                      <option value="" selected="selected">Filtrar empresa</option>
                      <?php foreach ($empresasCadastradas as $objDadosEmpresa):?>

                         <option value="<?= $objDadosEmpresa->id ?>"><?= $objDadosEmpresa->nome ?></option>

                      <?php endforeach; ?>

                    </select>
            </div>
              <div class="form-group">
              <input type="text" class="form-control" id="n4" name="filtro_assunto" value="" placeholder="Assunto">
            </div>
             <button type="button" onclick="filtrarDados()" class="btn btn-primary">Aplicar filtro</button>
             <button type="button" class="btn btn-default" onclick="limparFiltro()">Limpar filtro</button>
          </form>
        </div>
      </div>
</nav>




