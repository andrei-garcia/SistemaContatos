<?php 
session_start();

 if(!isset($_SESSION['nomeUsuario']) || isset($_SESSION['sair'])){
    session_destroy();
    header("Location: login/login.php");
 } 

?>

<table class="table">
	<thead>
		<th>Nome</th>
		<th>Tipo</th>
		<th>Editar</th>
                <th>Remover</th>
	</thead>
	<tbody>
                <?php if (empty($empresasCadastradas)):?>
                    <tr>
                        <td colspan="8">Nenhuma empresa cadastrada.</td>
                    </tr>
            
                <?php endif;?>
            
		<?php foreach ($empresasCadastradas as $objDadosEmpresa):?>
			<tr>
				<td><?= $objDadosEmpresa->nome ?></td>
				<td><?= $objDadosEmpresa->tipo ?></td>
				
				<td>
                                    <span class="glyphicon glyphicon-pencil btn btn-default btn-xs" onclick="obtemFormEmpresas('N', <?= $objDadosEmpresa->id ?>)"></span>
				</td>
                                <td>
                                    <span class="glyphicon glyphicon-remove btn btn-default btn-xs btn-danger" onclick="removeEmpresa(<?= $objDadosEmpresa->id ?>)"></span>
                                </td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<button type="button" onclick="obtemFormEmpresas('S','')" class="btn btn-success">Cadastrar nova empresa</button>
<div id="modalForm"></div>