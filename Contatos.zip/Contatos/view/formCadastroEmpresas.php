<?php 
    if($_POST['novo'] == 'S'){
        $id = "id='novaEmpresa' class='modal fade novaEmpresa'";
        $functionAcao = "cadastraNovaEmpresa()";
        $label = 'Cadastrar';
        $nome = 'Cadastrar nova empresa';
    }else{
        $id = "id='{$_POST['id']}' class='modal fade {$_POST['id']}'";
        $functionAcao = "atualizaDadosEmpresa('atualizaEmpresas',{$_POST['id']})";
        $label = 'Atualizar';
        $nome = $empresa->obtemNome();
    }
        
?>
<div <?= $id ?> tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel"><?= $nome ?></h4>
        </div>
        <div class="modal-body">
              <form>
                        <input type="hidden" name='id' value=<?= $_POST['id'] ?>>
                  <div class="form-group">
                            <label for="n1">Nome</label>
                            <input type="text" class="form-control" id="n1" name="nome" value="<?= $empresa->obtemNome(); ?>">
                          </div>
                          <div class="form-group">
                            <label for="n2">Tipo</label>
                            <input type="text" class="form-control" id="n2" name="tipo" value="<?= $empresa->obtemTipo(); ?>">
                         </div>
                          <button type="button" onclick="<?= $functionAcao ?>" class="btn btn-success"><?= $label ?> Empresa</button>
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                        </form>
                </div>
    </div>
  </div>
</div>