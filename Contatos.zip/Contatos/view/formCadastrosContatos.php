<?php 
    if($_POST['novo'] == 'S'){
        $id = "id='novoContato' class='modal fade novoContato'";
        $functionAcao = "cadastraNovo()";
        $label = 'Cadastrar';
        $nome = 'Cadastrar novo';
    }else{
        $id = "id='{$_POST['id']}' class='modal fade {$_POST['id']}'";
        $functionAcao = "atualizaDadosContatos('atualizaContatos',{$_POST['id']})";
        $label = 'Atualizar';
        $nome = $contato->obtemNome();
    }
        
?>
<div <?= $id ?> tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel"><?= $nome ?></h4>
        </div>
        <div class="modal-body">
              <form>
                        <input type="hidden" name='id' value=<?= $_POST['id'] ?>>
                            <div class="form-group">
                            <label for="n1">Nome</label>
                            <input type="text" class="form-control" id="n1" name="nome" value="<?= $contato->obtemNome(); ?>">
                          </div>
                        <div class="form-group">
                            <label for="n5">Empresa</label>
                            <select class="form-control" class="form-control" id="n5" name="empresa_id">
                              
                                <?php foreach ($empresasCadastradas as $objDadosEmpresa):?>
                                
                                    <?php if($objDadosEmpresa->id == $contato->obtemEmpresa()): ?>
                                        <option value="<?= $objDadosEmpresa->id ?>" selected="selected"><?= $objDadosEmpresa->nome ?></option>
                                    <?php else: ?>  
                                        <option value="<?= $objDadosEmpresa->id ?>"><?= $objDadosEmpresa->nome ?></option>
                                   <?php endif; ?>
                                        
                                <?php endforeach; ?>
                                
                              </select>
                          </div>
                          <div class="form-group">
                            <label for="n2">Cargo</label>
                            <input type="text" class="form-control" id="n2" name="cargo" value="<?= $contato->obtemCargo(); ?>">
                         </div>
                        <div class="form-group">   
                            <label for="n3">Email</label>
                            <input type="email" class="form-control" id="n3" name="email" value="<?= $contato->obtemEmail(); ?>">
                          </div>
                          <div class="form-group">
                            <label for="n4">Assunto</label>
                            <input type="text" class="form-control" id="n4" name="assunto" value="<?= $contato->obtemAssunto(); ?>">
                          </div>
                          <button type="button" onclick="<?= $functionAcao ?>" class="btn btn-success"><?= $label ?> Contato</button>
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                        </form>
                </div>
    </div>
  </div>
</div>
