<?php 
require_once '../class.Conexao.php';
session_start();

if(isset($_SESSION['nomeUsuario'])){
    header("Location: ../");
}

if(empty($_POST['usuario']) || empty($_POST['senha'])){
    $_SESSION['msg'] = "É preciso informar o usuário e a senha.";
    header("Location: login.php");
}

$conexao = new Conexao();
$con = $conexao->obtemDBPublica();
/* Connect to an ODBC database using driver invocation */
//$dsn = 'mysql:dbname=contatos;host=localhost';
//$user = "andrei";
//$password = "andrei";

$login = false;
$nomeUsuario = "";
$email = "";
try {
    //$con = new PDO($dsn,$user,$password);
    $sql = "SELECT email, senha, nome as descricao FROM usuarios WHERE email = ? or login = ? ";
	$res = $con->prepare($sql);
	$res->bindParam(1,$_POST['usuario']);
	$res->bindParam(2,$_POST['usuario']);
	$res->execute();

	if($res->rowCount() > 0){
            $row = $res->fetch(PDO::FETCH_OBJ);
            if($row->senha === $_POST['senha']){
                $login = true;
                $nomeUsuario = $row->descricao;
                $email = $row->email;
                $descricao = $row->descricao;
                $senha = $row->senha;
            }
	}
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    //exit();
}

if($login){
    $_SESSION['email'] = $email;
    $_SESSION['descricao'] = $descricao;
    $_SESSION['nomeUsuario'] = $nomeUsuario;
    $_SESSION['senha'] = $senha;
    header("Location: ../");
}else{
    $_SESSION['msg'] = "Senha ou usuário incorretos.";
    header("Location: login.php");
}