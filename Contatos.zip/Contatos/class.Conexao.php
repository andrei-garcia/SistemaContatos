<?php
/**
 * Description of class
 *
 * @author JoyceMarca
 */
class Conexao {
    
    public $dsn = 'mysql:dbname=contatos;host=localhost';
    public $user = "andrei";
    public $password = "andrei";
    public static $con = null;
    
    public function obtemDBPublica(){
        
        if($this->con === null){
            
            try {
            
                $this->con = new PDO($this->dsn, $this->user, $this->password);
    
            } catch (PDOException $e) {
                $this->con = null;
            }
            
        }
        
        return $this->con;
        
    }
    
}
