
function logout() {
	var posting = $.post("/Contatos/login/logout.php");
	 posting.done(function(data) {
	    location.reload();
  });
}

function filtrarDados(){
    var nome = $("[name='filtro_nome']").val(),
        assunto = $("[name='filtro_assunto']").val(),
        empresa = $("[name='filtro_empresa_id']").val();

    $.post( "controler/controler.php?acao=filtrarDados",
    {
        nome: nome,
        empresa: empresa,
        assunto: assunto
    
    },function(data) {
        $( ".main" ).html( data );
    });
}

function limparFiltro(){
    $('#filtroContatos')[0].reset();
    listaDados('listaContatos');
}

function listaDados(acao){
    $.get( "controler/controler.php?acao="+acao, function( data ) {
      $( ".main" ).html( data );
    });
}

function obtemFormFiltroContatos(){
    $.get( "controler/controler.php?acao=obtemFormFiltroContatos", function( data ) {
      $( ".filtroContatos" ).html( data );
    });
}

function limpaDivFiltro(){
     $( ".filtroContatos" ).html('');
}

function cadastraNovaEmpresa(){
    
    var nome = $("[name='nome']").val(),
        tipo = $("[name='tipo']").val();

    if(nome === '' || tipo === ''){
        alert('Favor preencher todos os campos do formulário.')
        return false;
    }
    
    $('#novaEmpresa').modal('hide');
    $.post( "controler/controler.php?acao=cadastraNovaEmpresa",
    {
        nome: nome,
        tipo: tipo
    
    },function() {
        setTimeout( listaDados, 250, 'listaEmpresas');
    });
    
}

function cadastraNovo(){
    
     var nome = $("[name='nome']").val(),
        cargo = $("[name='cargo']").val(),
        email = $("[name='email']").val(),
        assunto =  $("[name='assunto']").val(),
        empresa_id = $("[name='empresa_id']").val();
    
    if(IsEmail(email)===false){
        alert('e-mail inválido!')
        return false;
    }
    
    if(nome === '' || cargo === '' || email === '' || assunto === '' || empresa_id === ''){
        alert('Favor preencher todos os campos do formulário.')
        return false;
    }
    
    $('#novoContato').modal('hide');
    $.post( "controler/controler.php?acao=novoContato",
    {
        nome: nome,
        cargo: cargo,
        email: email,
        assunto:  assunto,
        empresa_id: empresa_id
    
    },function() {
        setTimeout( listaDados, 250, 'listaContatos');
    });
    
}

function obtemFormEmpresas(novo,id){
    $.post( "controler/controler.php?acao=obtemFormEmpresas",{
        novo: novo,
        id: id
    }, 
    function( data ) {
      $( "#modalForm" ).html( data );
      $('#novaEmpresa').modal('show');
    });
    
    if(id !== ''){
        setTimeout(function(id){
            $('#'+id).modal('show');
        }, 250, id);
    }
    
}

function obtemFormContatos(novo,id){
    $.post( "controler/controler.php?acao=obtemFormContatos",{
        novo: novo,
        id: id
    }, 
    function( data ) {
      $( "#modalForm" ).html( data );
      $('#novoContato').modal('show');
    });
    
    if(id !== ''){
        setTimeout(function(id){
            $('#'+id).modal('show');
        }, 250, id);
    }
    
}


function removeContato(id){
    
    $.post( "controler/controler.php?acao=removerContato",
    {
        id: id
    
    },function() {
        setTimeout( listaDados, 150, 'listaContatos');
    });
    
}

function removeEmpresa(id){
    
    $.post( "controler/controler.php?acao=removerEmpresa",
    {
        id: id
    
    },function() {
        setTimeout( listaDados, 150, 'listaEmpresas');
    });
    
}

function atualizaDadosEmpresa(acao,id){
    
    var nome = $("[name='nome']").val(),
        tipo = $("[name='tipo']").val();
    
    if(nome === '' || tipo === ''){
        alert('Favor preencher todos os campos do formulário.')
        return false;
    }
    
    $('#'+id).modal('hide');
    $.post( "controler/controler.php?acao="+acao,
    {
        nome: nome,
        tipo: tipo,
        id: id
    
    },function() {
        setTimeout( listaDados, 250, 'listaEmpresas');
    });
    
}

function IsEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if(!regex.test(email)) {
       return false;
    }else{
       return true;
    }
}

function atualizaDadosContatos(acao,id){
    
    var nome = $("[name='nome']").val(),
        cargo = $("[name='cargo']").val(),
        email = $("[name='email']").val(),
        assunto =  $("[name='assunto']").val(),
        empresa_id = $("[name='empresa_id']").val();
    
    if(IsEmail(email)===false){
        alert('e-mail inválido!')
        return false;
    }
    
    if(nome === '' || cargo === '' || email === '' || assunto === '' || empresa_id === ''){
        alert('Favor preencher todos os campos do formulário.')
        return false;
    }
    
    $('#'+id).modal('hide');
    $.post( "controler/controler.php?acao="+acao,
    {
        nome: nome,
        cargo: cargo,
        email: email,
        assunto:  assunto,
        empresa_id: empresa_id,
        id: id
    
    },function() {
        setTimeout( listaDados, 250, 'listaContatos');
    });
    
}

