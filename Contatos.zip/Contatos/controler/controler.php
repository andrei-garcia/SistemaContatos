<?php
require_once '../class.Conexao.php';
require_once '../model/class.Contatos.php';
require_once '../model/class.Empresas.php';

$conexao = new Conexao();
$db = $conexao->obtemDBPublica();

$contato = new Contatos();
$empresa = new Empresas();

$contato->defineConexao($db);
$empresa->defineConexao($db);

switch ($_GET['acao']) {
    case 'filtrarDados':
        
        $filtro = array();
        
        if(!empty($_POST['empresa']))
            $filtro[] = "contatos.empresa_id = {$_POST['empresa']}";
        
        if(!empty($_POST['nome']))
            $filtro[] = "contatos.nome like '%{$_POST['nome']}%'";
            
        if(!empty($_POST['assunto']))
            $filtro[] = "contatos.assunto like '%{$_POST['assunto']}%'";
        
        if(!empty($filtro))
           $filtro = implode (' and ', $filtro);
        else
           $filtro = '1';
               
        $contatosCadastrados = $contato->obtemContatosCadastados($filtro);
        require_once '../view/viewContatos.php';
        
        break;
    case 'obtemFormFiltroContatos':
        $empresasCadastradas = $empresa->obtemEmpresasCadastradas();
        require_once '../view/filtroContatos.php';
        break;
    case 'novoContato':
        
        $contato->defineAssunto($_POST['assunto']);
        $contato->defineEmail($_POST['email']);
        $contato->defineNome($_POST['nome']);
        $contato->defineCargo($_POST['cargo']);
        $contato->defineEmpresa($_POST['empresa_id']);
        $contato->cadastra();
        
        break;
    case 'cadastraNovaEmpresa':
        
        $empresa->defineNome($_POST['nome']);
        $empresa->defineTipo($_POST['tipo']);
        $empresa->cadastra();
        
        break;
    case 'obtemFormEmpresas':
        $empresa->defineId($_POST['id']);
        
        require_once '../view/formCadastroEmpresas.php';
        break;
    case 'obtemFormContatos':
        $empresasCadastradas = $empresa->obtemEmpresasCadastradas();
        $contato->defineId($_POST['id']);
        require_once '../view/formCadastrosContatos.php';
        break;
    case 'listaContatos':
        
        $contatosCadastrados = $contato->obtemContatosCadastados();
        require_once '../view/viewContatos.php';
        
        break;
    case 'listaEmpresas':
        
        $empresasCadastradas = $empresa->obtemEmpresasCadastradas();
        require_once '../view/viewEmpresas.php';
        
        break;
    case 'atualizaEmpresas':
        
        $empresa->defineId($_POST['id']);
        $empresa->defineNome($_POST['nome']);
        $empresa->defineTipo($_POST['tipo']);
        $empresa->atualiza();
        
        break;
    case 'atualizaContatos':
        
        $contato->defineId($_POST['id']);
        $contato->defineAssunto($_POST['assunto']);
        $contato->defineEmail($_POST['email']);
        $contato->defineNome($_POST['nome']);
        $contato->defineCargo($_POST['cargo']);
        $contato->defineEmpresa($_POST['empresa_id']);
        $contato->atualiza();
        
        break;
    case 'removerContato':
        
        $contato->defineId($_POST['id']);
        $contato->remove();
        
        break;
    case 'removerEmpresa':
        $empresa->defineId($_POST['id']);
        $empresa->remove();
        break;
    default:
        header("Location: ../");
        break;
}

