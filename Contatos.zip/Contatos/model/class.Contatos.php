<?php

/**
 * Description of class
 *
 * @author Andrei Garcia
 */
class Contatos {

    private $dados = array();
    private $conexao = null;
    
    public function defineConexao($con){
        $this->conexao = $con;
    }
    
    public function defineNome($nome){
        $this->dados['nome'] = $nome;
    }
    
    public function defineId($id){
        $this->dados['id'] = $id;
        $sql = "
          select 
                *
          from contatos
          where id = ?
        ";
        
        $res = $this->conexao->prepare($sql);
	$res->bindParam(1, $this->dados['id']);
	$res->execute();
        
        
        while($row = $res->fetch(PDO::FETCH_OBJ)){
            
            $this->dados['cargo'] = $row->cargo;
            $this->dados['email'] = $row->email;
            $this->dados['assunto'] = $row->assunto;
            $this->dados['nome'] = $row->nome;
            $this->dados['empresa_id'] = $row->empresa_id;
        }
    }
    
    public function defineCargo($cargo){
        $this->dados['cargo'] = $cargo;
    }
    
    public function defineEmpresa($empresa){
        $this->dados['empresa_id'] = $empresa;
    }
    
    public function defineEmail($email){
        $this->dados['email'] = $email;
    }
    
    public function defineAssunto($assunto){
        $this->dados['assunto'] = $assunto;
    }
    
    
    public function obtemNome(){
        return $this->dados['nome'];
    }
    
    public function obtemCargo(){
        return $this->dados['cargo'];
    }
    
    public function obtemEmpresa(){
        return $this->dados['empresa_id'];
    }
    
    public function obtemEmail(){
        return $this->dados['email'];
    }
    
    public function obtemAssunto(){
        return $this->dados['assunto'];
    }
    
    public function obtemContatosCadastados($filtro = '1'){
        
        $sql = "
          select 
                contatos.*,
                empresas.nome as empresa,
                empresas.tipo
          from contatos
          left join empresas ON
            empresas.id = contatos.empresa_id
         where 
             {$filtro}
          order by
            empresas.nome asc, contatos.nome asc
        ";
        
        $res = $this->conexao->prepare($sql);
	$res->execute();
        
       
        $dadosContatos = array();
        
        while($row = $res->fetch(PDO::FETCH_OBJ)){
            $dadosContatos[]  = $row;
        }
        
        return $dadosContatos;
    }
    
    public function atualiza(){
        $sql = "UPDATE contatos set  nome = ?, cargo = ?, email = ?, assunto = ?, empresa_id = ? where id = ?";
	$res = $this->conexao->prepare($sql);
        
	$res->bindParam(1, $this->dados['nome']);
	$res->bindParam(2, $this->dados['cargo']);
        $res->bindParam(3, $this->dados['email']);
        $res->bindParam(4, $this->dados['assunto']);
        $res->bindParam(5, $this->dados['empresa_id']);
        $res->bindParam(6, $this->dados['id']);
        
	$res->execute();
    }
    
    public function remove(){
        $sql = "DELETE FROM contatos where id = ?";
	$res = $this->conexao->prepare($sql);
        
	$res->bindParam(1, $this->dados['id']);
	$res->execute();
    }
    
    public function cadastra(){
        $sql = "INSERT INTO contatos (nome,cargo,email,assunto, empresa_id) VALUES (:nome,:cargo,:email,:assunto,:empresa_id)";
	$res = $this->conexao->prepare($sql);
        
	$res->bindParam(':nome', $this->dados['nome']);
	$res->bindParam(':cargo', $this->dados['cargo']);
        $res->bindParam(':email', $this->dados['email']);
        $res->bindParam(':assunto', $this->dados['assunto']);
        $res->bindParam(':empresa_id', $this->dados['empresa_id']);
       
	$res->execute();
    }
}
