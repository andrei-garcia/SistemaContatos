<?php

/**
 * Description of class
 *
 * @author Andrei Garcia
 */
class Empresas {

    private $dados = array();
    private $conexao = null;
    
    public function defineConexao($con){
        $this->conexao = $con;
    }
    
    public function defineNome($nome){
        $this->dados['nome'] = $nome;
    }
    
    public function defineId($id){
        $this->dados['id'] = $id;
        $sql = "
          select 
                *
          from empresas
          where id = ?
        ";
        
        $res = $this->conexao->prepare($sql);
	$res->bindParam(1, $this->dados['id']);
	$res->execute();
        
        while($row = $res->fetch(PDO::FETCH_OBJ)){
           
            $this->dados['nome'] = $row->nome;
            $this->dados['tipo'] = $row->tipo;
            
        }
    }
    
    public function defineTipo($tipo){
        $this->dados['tipo'] = $tipo;
    }
    
  
    public function obtemNome(){
        return $this->dados['nome'];
    }
    
    public function obtemTipo(){
        return $this->dados['tipo'];
    }
    
  
    public function obtemEmpresasCadastradas(){
        $sql = "
          select 
                *
          from empresas
          order by
           nome asc
        ";
        
        $res = $this->conexao->query($sql);
        $dados = array();
        
        while($row = $res->fetch(PDO::FETCH_OBJ)){
            $dados[]  = $row;
        }
        
        return $dados;
    }
    
    public function atualiza(){
        $sql = "UPDATE empresas set  nome = ?, tipo = ?  where id = ?";
	$res = $this->conexao->prepare($sql);
        
	$res->bindParam(1, $this->dados['nome']);
	$res->bindParam(2, $this->dados['tipo']);
        $res->bindParam(3, $this->dados['id']);
        
	$res->execute();
    }
    
    public function remove(){
        $sql = "DELETE FROM empresas where id = ?";
	$res = $this->conexao->prepare($sql);
        
	$res->bindParam(1, $this->dados['id']);
	$res->execute();
    }
    
    public function cadastra(){
        $sql = "INSERT INTO empresas (nome,tipo) VALUES (:nome,:tipo)";
	$res = $this->conexao->prepare($sql);
        
	$res->bindParam(':nome', $this->dados['nome']);
	$res->bindParam(':tipo', $this->dados['tipo']);
       
	$res->execute();
    }
}
